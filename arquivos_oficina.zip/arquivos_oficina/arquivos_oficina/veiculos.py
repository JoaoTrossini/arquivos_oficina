
import re
from datetime import date

from db import ErroNegocio, execute, query


SELECT_VEICULOS = (
    "SELECT v.id, v.cliente_id, c.nome AS cliente_nome, "
    "v.placa, v.marca, v.modelo, v.ano, v.cor "
    "FROM veiculos v "
    "JOIN clientes c ON c.id = v.cliente_id "
)


def _validar(d):
    placa = (d.get("placa") or "").upper().replace("-", "").strip()

    if not re.fullmatch(r"[A-Z]{3}[0-9][A-Z0-9][0-9]{2}", placa):
        raise ErroNegocio("Placa inválida (ABC1D23).")

    marca = (d.get("marca") or "").strip()
    modelo = (d.get("modelo") or "").strip()

    if not marca or not modelo:
        raise ErroNegocio("Informe a marca e o modelo.")

    try:
        ano = int(d.get("ano"))
    except (TypeError, ValueError):
        raise ErroNegocio("Ano inválido.")

    if not 1950 <= ano <= date.today().year + 1:
        raise ErroNegocio("Ano fora do intervalo permitido.")

    try:
        cliente_id = int(d.get("cliente_id"))
    except (TypeError, ValueError):
        raise ErroNegocio("Selecione o proprietário do veículo.")

    if not query(
        "SELECT id FROM clientes WHERE id = %s",
        (cliente_id,)
    ):
        raise ErroNegocio("O cliente não está cadastrado.", 404)

    return placa, ano, cliente_id


def listar():
    return query(
        SELECT_VEICULOS + " ORDER BY c.nome, v.modelo"
    )


def obter(id_):
    resultado = query(
        SELECT_VEICULOS + " WHERE v.id = %s",
        (id_,)
    )

    if not resultado:
        raise ErroNegocio("Veículo não encontrado.", 404)

    return resultado[0]


def _placa_em_uso(placa, ignorar=0):
    return query(
        "SELECT id FROM veiculos "
        "WHERE placa = %s AND id <> %s",
        (placa, ignorar)
    )


def cadastrar(d):
    placa, ano, cliente_id = _validar(d)

    if _placa_em_uso(placa):
        raise ErroNegocio("Placa já cadastrada.", 409)

    resultado = execute(
        "INSERT INTO veiculos "
        "(cliente_id, placa, marca, modelo, ano, cor) "
        "VALUES (%s, %s, %s, %s, %s, %s)",
        (
            cliente_id,
            placa,
            d["marca"].strip(),
            d["modelo"].strip(),
            ano,
            d.get("cor")
        )
    )

    id_ = resultado[0] if isinstance(resultado, (tuple, list)) else resultado

    return obter(id_)


def editar(id_, d):
    obter(id_)

    placa, ano, cliente_id = _validar(d)

    if _placa_em_uso(placa, id_):
        raise ErroNegocio(
            "Placa já cadastrada em outro veículo.",
            409
        )

    execute(
        "UPDATE veiculos SET "
        "cliente_id = %s, placa = %s, marca = %s, "
        "modelo = %s, ano = %s, cor = %s "
        "WHERE id = %s",
        (
            cliente_id,
            placa,
            d["marca"].strip(),
            d["modelo"].strip(),
            ano,
            d.get("cor"),
            id_
        )
    )

    return obter(id_)


def excluir(id_):
    obter(id_)

    agendamentos = query(
        "SELECT id FROM agendamentos "
        "WHERE veiculo_id = %s LIMIT 1",
        (id_,)
    )

    if agendamentos:
        raise ErroNegocio(
            "O veículo possui agendamentos. "
            "Exclua-os antes de excluir o veículo.",
            409
        )

    execute(
        "DELETE FROM veiculos WHERE id = %s",
        (id_,)
    )
