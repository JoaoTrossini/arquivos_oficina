
from db import testar_conexao

try:
    print("Conexão OK:", testar_conexao())
except Exception as e:
    print("Falha na conexão:", e)
